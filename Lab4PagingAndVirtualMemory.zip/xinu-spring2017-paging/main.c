/*  main.c  - main */

#include <xinu.h>
#include <stdio.h>

/*void dump32(unsigned long n) {
  int i;

  for(i = 31; i>=0; i--) {
    kprintf("%02d ",i);
  }

  kprintf("\n");

  for(i=31;i>=0;i--)
    kprintf("%d  ", (n&(1<<i)) >> i);

  kprintf("\n");
}
*/



int fun1(){

	struct procent *prptr;
	pd_t *pd;
	pt_t *pt;
	prptr=&proctab[currpid];

	kprintf("Running %s process\n",prptr->prname);
	int i=0;

	int *x;

	x=vgetmem(1000);

//	kprintf("X gives %d \n",x);
//	kprintf("X values %d\n",(*x));
//	printdir(prptr->pdir);
//	*x=100;
/*	x++;
	pd = prptr->pdir;
	pt = (pt_t *)(pd[4].pd_base);
	for(i=0; i<10; i++) {
		kprintf("PT %d %d\n", &pt[i], (pt[i].pt_base));
	}

	kprintf("Done %s process\n",prptr->prname);
	
*/	return 0;

}

process	main(void)
{

	pid32 p1,p2,p3,p4,p5;
	int bs=0;
	/* Start the network */
	/* DO NOT REMOVE OR COMMENT THIS CALL */
	netstart();

	/* Initialize the page server */
	/* DO NOT REMOVE OR COMMENT THIS CALL */
	psinit();
	srpolicy(GCA);
	kprintf("=== Lab4 ===\n");
	kprintf("%d\n",bscounter());
	//srpolicy(GCA);
//	srpolicy=FIFO;
//	printbsmap();


	p1=vcreate(fun1,4096,500,40,"p1",0);


//	printbsmap();


	p2=vcreate(fun1,4096,435,40,"p2",0);


//	printbsmap();

//	p3=vcreate(fun1,4096,700,40,"3",0);


//	printbsmap();


//	p4=vcreate(fun1,4096,300,40,"4",0);


//	printbsmap();

	resume(p1);
	resume(p2);
//	resume(p3);
//	resume(p4);
//	sleepms(1000);
//	printiptab();
	
//	char* addr = (uint32) 4096*5000;
	kprintf("Main: %d \n",availframes);
//	dump32(readcr0());
	//dump32(readc3());
	return OK;
}
