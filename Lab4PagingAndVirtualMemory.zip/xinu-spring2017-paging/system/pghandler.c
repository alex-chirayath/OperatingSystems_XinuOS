#include <xinu.h>

/*------------------------------------------------------------------------
 *  * pghandler - high level clock interrupt handler
 *   *------------------------------------------------------------------------
 *    */

//int faults;

void    pghandler()
{

unsigned long a;
int 	vp,p,q;
struct procent *prptr;
 pd_t *pd;
 pt_t *pt;
int mybs,offset,bsread;
pid32 pid;
int myframe;
	kprintf("Handler called\n");
	
	a=readcr2();
	kprintf("CR2 %d\n",a/NBPG);	
	
	hook_pfault((void * )a);



	faults++;
	vp=a>>12;
	p=a>>22;
	q=vp & 0x000003FF;

	prptr=&proctab[currpid];
	pd=prptr->pdir;
	

	mybs=checkbsmap(vp,currpid);
	if(SYSERR==mybs){
	
	kprintf("Not valid address for Handler\n");
	kill(currpid);

	}	

	offset=getoffset(vp,mybs);
	
	
	if(pd[p].pd_pres==0){
		kprintf("Fault because table not present\n");

		pt=getPTab();

		pd[p].pd_pres 	= 1;
		pd[p].pd_write	= 1;
		pd[p].pd_user	= 0;
		pd[p].pd_pwt	= 0;
		pd[p].pd_pcd 	= 0;
		pd[p].pd_acc 	= 0;
		pd[p].pd_mbz 	= 0;
		pd[p].pd_fmb 	= 0;
		pd[p].pd_global = 0;
		pd[p].pd_avail 	= 0;
		pd[p].pd_base 	=(uint32) pt>>12;


	//	pt =(pt_t *)(pd[p].pd_base<<12);

		myframe=getframe();
		
		pt[q].pt_pres 	= 1;
		pt[q].pt_write	= 1;
		pt[q].pt_user	= 0;
		pt[q].pt_pwt	= 0;
		pt[q].pt_pcd 	= 0;
		pt[q].pt_acc 	= 0;
		pt[q].pt_dirty 	= 0;
		pt[q].pt_mbz 	= 0;
		pt[q].pt_global = 0;
		pt[q].pt_avail 	= 0;
		pt[q].pt_base 	= myframe;

	//	iptable[myframe-FRAMEONE].pid=currpid;
		iptable[myframe-FRAME0].vpage=vp;

			



	}else if (pd[p].pd_pres==1){
		kprintf("Fault because page not present\n");

		pt =(pt_t *)(pd[p].pd_base<<12);

		myframe=getframe();
		
		pt[q].pt_pres 	= 1;
		pt[q].pt_write	= 1;
		pt[q].pt_user	= 0;
		pt[q].pt_pwt	= 0;
		pt[q].pt_pcd 	= 0;
		pt[q].pt_acc 	= 0;
		pt[q].pt_dirty 	= 0;
		pt[q].pt_mbz 	= 0;
		pt[q].pt_global = 0;
		pt[q].pt_avail 	= 0;
		pt[q].pt_base 	= myframe;

		iptable[myframe-FRAME0].vpage=vp;
		
		

	}

	

		bsread=read_bs(myframe<<12,mybs,offset);
		if(bsread==SYSERR){
		
		kprintf("Handler could not read from bs\n");
		kill(currpid);
		}
		
		iptable[pd[p].pd_base-FRAME0].refcount+=1;

	
			


//		faults++;
}
