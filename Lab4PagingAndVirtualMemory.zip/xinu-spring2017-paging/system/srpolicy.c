/* srpolicy.c - srpolicy */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  srplicy  -  Set the page replacement policy.
 *------------------------------------------------------------------------
 */


uint32 spolicy;

syscall srpolicy(int policy)
{
	switch (policy) {
	case FIFO:
		spolicy=FIFO;
		return OK;

	case GCA:
		spolicy=GCA;
		return OK;

	default:
		return SYSERR;
	}
}
