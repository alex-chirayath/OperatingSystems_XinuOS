#include <xinu.h>



invptable iptable[NFRAMES];
backstoremap bsmap[MAX_BS_ENTRIES];	
int iphead,iptail;
//uint32 spolicy =FIFO;

void printdir(char* addr)
 
  {
   
   
   	kprintf("***************PrintDir*******\n");
   	pd_t* newpt_t = (pd_t *) addr;
         int count;
         for(count = 0; count < 10; count++)
         {
                 kprintf("Value at %d is %d; add: %d\n", count, newpt_t->pd_base, newpt_t);
                 newpt_t++; //(sizeof(pt_t));
         }
 }





	




void iptableinit(){

	int i=0;
	iphead=iptail=-1;

	while (i<NFRAMES){
	
		iptable[i].pid=-1;
//		iptable[i].fid=i;
		iptable[i].fstate=F_FREE;
		iptable[i].vpage=0;
		iptable[i].refcount=0;
		iptable[i].fnext=-1;
		i++;

	}

}


void bsmapinit()
{
	int i=0;
	
	
	while( i<MAX_BS_ENTRIES) 
	{
		
		bsmap[i].pid = -1; 
		bsmap[i].vpage = 0;
		bsmap[i].npages = 0;


		i++;
	}
}


int getframe() {
    
   	kprintf("***************GETFRAME*******\n"); 
        static int frame = 0; 			//PUT CHECK IF GOES ABOVE A NUMBER
        int i=0;
	int temp;
	int myframe;
	int replaceCandidate;
	
	if(availframes>NFRAMES||availframes<0){
	
	kprintf("Some frame error\n");
	return SYSERR;
	}
	else if(availframes>0 ){

		
			for(i=0;i<NFRAMES;i++){
				frame %= NFRAMES;		
				if(iptable[frame].fstate==F_FREE){
				
					temp=frame+FRAME0;
					frame++;
					break;
				}
				frame++;
			}

	}else if(spolicy==FIFO ){
	
	kprintf("FIFO POLICY\n");
	temp=getFIFOcandidate();
	
	
	if(temp==SYSERR)
		{
		  kprintf("FIFO Could not find a candidate\n");
		  return SYSERR;
		}
	myframe=temp-FRAME0;
	clearframe(temp);	

	} else if(spolicy==GCA){

	kprintf("GCA POLICY\n");
	temp=getGCAcandidate();
		if(temp==SYSERR){
	
			kprintf("No GCA Candidate\n");
			return SYSERR;
		}
	myframe=temp-FRAME0;
	clearframe(temp);

	}




	if(spolicy==FIFO){
		if(iphead==-1)
			iphead=temp;
		else
			iptable[iptail-FRAME0].fnext=temp;

		iptail=temp;
	}
/*	else if(spolicy==GCA){
		
		}

*/

	iptable[temp-FRAME0].vpage=0;//(frame+FRAME0)*4096;
	iptable[temp-FRAME0].fstate=F_USED;
	iptable[temp-FRAME0].pid=currpid;
	iptable[temp-FRAME0].fnext=-1;
	iptable[temp-FRAME0].refcount=0;
	kprintf("Get frame : %d  pid %d  state %d\n", frame,iptable[frame].pid,iptable[frame].fstate);

	availframes--;
	kprintf("Frame ALLOCATED :%d\n",temp);
	
//	printiptab();
	
	
	return temp;
}

int getFIFOcandidate(){
 
   	kprintf("***************GET FIFO*******\n");
	int curr=iphead;
	int prev=-1;

	while((curr)!=iptable[iptail-FRAME0].fnext){
	
		if(iptable[curr-FRAME0].fstate!=F_GLOBAL && iptable[curr-FRAME0].fstate!=F_TAB && iptable[curr-FRAME0].fstate!=F_DIR){
	

		if(curr==iphead){
			iphead=iptable[curr-FRAME0].fnext;
		//	return curr;
		}
		else if(curr==iptail){
			kprintf("TAil updaed %d\n",prev);
			iptail=prev;
			iptable[prev-FRAME0].fnext=-1;

		}else{

			iptable[prev-FRAME0].fnext=iptable[curr-FRAME0].fnext;

			
			}
		
//		if(iptable[curr-FRAME0].fstate==F_DIRTY){
		


//		}

	

		return curr;

		}
	prev=curr;
	curr=iptable[curr-FRAME0].fnext;
	}

	return SYSERR;
}



int getGCAcandidate(){
	int i=0;
	int frame=-1;
	pid32 pid;
	int vp,p,q;
	unsigned long a;
	pd_t *pd;
	pt_t *pt;
	struct procent *prptr;
 
   	kprintf("***************get GCA*******\n");	
	while(TRUE){
	
	//	kprintf("LOop 1\n");
		i=(i+1)%NFRAMES;


			if(iptable[i].fstate==F_DIR||iptable[i].fstate==F_GLOBAL||iptable[i].fstate==F_TAB)
				continue;
	
			vp=iptable[i].vpage;
			a=vp*4096;
			p=a>22;
			q=vp & 0x000003FF;
	
			pid=iptable[i].pid;
			prptr =&proctab[pid];

			pd=prptr->pdir;
	
			pt=(pt_t *)(pd[p].pd_base<<12);
	
				
			 if(pt[q].pt_acc==0)
			 {
				kprintf("Acc 0\n");
				frame=i+FRAME0;	
				break;			
			 } else
			 if (pt[q].pt_dirty==1) {
				
				kprintf("dirty 1\n");
				pt[q].pt_dirty=0;
				pt[q].pt_avail=4;				

			} else 
			if(pt[q].pt_acc==1){
			   	pt[q].pt_acc=0;
				kprintf("Acc 1 - %d\n", q);
			}
	

		}
	
	for (i=0;i<NFRAMES;i++){
	

			if(iptable[i].fstate==F_DIR||iptable[i].fstate==F_GLOBAL||iptable[i].fstate==F_TAB)
				continue;
	
			vp=iptable[i].vpage;
			a=vp*4096;
			p=a>22;
			q=vp & 0x000003FF;
	
			pid=iptable[i].pid;
			prptr =&proctab[pid];

			pd=prptr->pdir;
	
			pt=(pt_t *)(pd[p].pd_base<<12);
	
			if(pt[q].pt_avail==4){
			
			pt[q].pt_acc=1;
			pt[q].pt_dirty=1;
			pt[q].pt_avail=1;
			}
		
	}
	
 return frame;

}




pt_t *getPTab() {


 
   	kprintf("***************GET TAB*******\n");
    int f;
	pt_t *pt;
	int i;
	f = getframe();
	if(f==SYSERR)
		{
			kprintf("NO Frame from fifo for Tab\n");
			return SYSERR;
		}

	kprintf("Frame : %d\n", f);

	pt = (pt_t *) (f * PGSIZE);
	
	
	for(i = 0; i < PTENTRIES; i++) {
		pt[i].pt_pres 	= 0;
		pt[i].pt_write	= 1;
		pt[i].pt_user	= 0;
		pt[i].pt_pwt	= 0;
		pt[i].pt_pcd 	= 0;
		pt[i].pt_acc 	= 0;
		pt[i].pt_dirty 	= 0;
		pt[i].pt_mbz 	= 0;
		pt[i].pt_global = 0;
		pt[i].pt_avail 	= 0;
		pt[i].pt_base 	= 0;
	}

	iptable[f-FRAME0].vpage=f;
	iptable[f-FRAME0].fstate=F_TAB;
	
//	kprintf("TAB pid %d fstate %d vpage %d\n",f,iptable[f].pid,iptable[f].fstate,iptable[f].vpage);

    hook_ptable_create(f-FRAME0);   
    return pt;
}






pd_t *getPDir() {
	
	pd_t *pd;
	int i;
	int f = getframe();
 
  	kprintf("***************get DIR*******\n");	
	if(f==SYSERR)
	{
	kprintf("NO frame for Dir\n");
	return SYSERR;
	}
//	kprintf("Frame %d\n", f);
	
	pd = (pd_t *) (f*4096);

	// initialize page directory entries
	for(i = 0; i < PTENTRIES; i++) {
		pd[i].pd_pres 	= 0;
		pd[i].pd_write	= 1;
		pd[i].pd_user	= 0;
		pd[i].pd_pwt	= 0;
		pd[i].pd_pcd 	= 0;
		pd[i].pd_acc 	= 0;
		pd[i].pd_mbz 	= 0;
		pd[i].pd_fmb 	= 0;
		pd[i].pd_global = 0;
		pd[i].pd_avail 	= 0;
		pd[i].pd_base 	= 0;
	}
	
        int currframe = FRAME0+1;
	// add information for shared global page tables
	for(i = 0; i < 4; i++) {
		pd[i].pd_pres 	= 1;
		pd[i].pd_avail 	= 1;
		pd[i].pd_base 	= currframe++;
	}
	
	pd[576].pd_pres 	= 1;
	pd[576].pd_avail 	= 1;
	kprintf("Setting pdbase 576 as %ucal\n",currframe);
	pd[576].pd_base 	= currframe;
//	kprintf(" pdbase 576 as %u\n",pd[576].pd_base);

	iptable[f-FRAME0].vpage=f;
	iptable[f-FRAME0].fstate=F_DIR;
	


	kprintf("DIR  %d pid %d fstate %d vpage %d\n",f-FRAME0,iptable[f-FRAME0].pid,iptable[f-FRAME0].fstate,iptable[f-FRAME0].vpage);

	return pd;
}





int globalTabinit() {

	int i, j;

	pt_t *pt;








	for(i = 0; i < 4; i++) {
		pt = getPTab();
		if(pt == NULL) {
			return SYSERR;
		}
		for(j = 0; j < PTENTRIES; j++) {

			pt[j].pt_pres 	= 1;
			pt[j].pt_write	= 1;
			pt[j].pt_user	= 0;
			pt[j].pt_pwt	= 0;
			pt[j].pt_pcd 	= 0;
			pt[j].pt_acc 	= 0;
			pt[j].pt_dirty 	= 0;
			pt[j].pt_mbz 	= 0;
			pt[j].pt_global = 0;
			pt[j].pt_avail 	= 1;


			pt[j].pt_base 	= i * PTENTRIES + j;
		}

}



	// dev memory page table

	pt = getPTab();
	if(pt == NULL) {
		return SYSERR;
	}


	for(j = 0; j < PTENTRIES; j++) {

		pt[j].pt_pres 	= 1;
		pt[j].pt_write	= 1;
		pt[j].pt_user	= 0;
		pt[j].pt_pwt	= 0;
		pt[j].pt_pcd 	= 0;
		pt[j].pt_acc 	= 0;
		pt[j].pt_dirty 	= 0;
		pt[j].pt_mbz 	= 0;
		pt[j].pt_global = 0;
		pt[j].pt_avail 	= 1;
		pt[j].pt_base 	= DEVICEMEM   + j;
	}





	for(i=0;i<6;i++)
	{


			iptable[i].fstate=F_GLOBAL;
			iptable[i].pid=NULLPROC;


		kprintf("global  %d pid %d fstate %d vpage %d\n",i,iptable[i].pid,iptable[i].fstate,iptable[i].vpage);

	
	}




	return OK;
	
}


//==================== BackStore Checks ======================

int bscounter(void){
	
	int i;
	int counter=0;

	for( i=0;i<MAX_BS_ENTRIES;i++){

		if(!bstab[i].isallocated)
			counter++;

	}

return counter;

}


//=================Back store allocation in vcreate() =========

syscall heaptobsmap(pid32 pid){


  kprintf("***************heap to bs*******\n"); 

	struct procent *prptr;
	prptr=&proctab[pid];

	uint32 prhsize=prptr->hsize;
	uint32 size,offset;
	size=offset=0;

	while(prhsize>0 ){
	
		if(prhsize<=MAX_PAGES_PER_BS){
		
		size=prhsize;

		}
		else
		size=MAX_PAGES_PER_BS;
	
		
	   	prhsize=prhsize-size;
	   	
	//	kprintf("aaa\n");
		bsd_t bs;
	   	if( (bs=allocate_bs(size)) ==SYSERR){
	   
			kprintf("Error in bs_allocate\n");
		   	clearbsmap(pid);
	   
	   	   	return SYSERR;

	   	}
	//	kprintf("bbb\n");

		addbsmap(bs,pid,4096+offset,size);
		
 	 	offset+=size;
	  
	  }

	return OK;
}



syscall clearbsmap(pid32 pid){

	int i;

  kprintf("***************clear bsmap*******\n"); 

	for(i=0;i<MAX_BS_ENTRIES;i++){
		if(bsmap[i].pid==pid){
		
		bsmap[i].vpage=0;
		bsmap[i].pid=-1;
		bsmap[i].npages=0;
		
					//deallocate the backstore
			if(SYSERR==deallocate_bs(i)){
				kprintf("Cannot deallocate bstore\n");
				
				return SYSERR;
			}

		}
	
	

	}

return OK;
}


void addbsmap(bsd_t bs,pid32 pid,uint32 vpage,uint32 npages){

   	kprintf("***************Add bsmap*******\n"); 
	bsmap[bs].pid=pid;
	bsmap[bs].npages=npages;
	bsmap[bs].vpage=vpage;

}

void printbsmap(){

int i=0;


	for(i=0;i<MAX_BS_ENTRIES;i++){
	
	kprintf("BS %d =>pid %d npages %d vpage %d\n",i,bsmap[i].pid,bsmap[i].npages,bsmap[i].vpage);

	}

}



int checkbsmap(unsigned long vp, pid32 pid){
int i;

   	kprintf("***************Check bsmap*******\n"); 
	for(i=0;i<MAX_BS_ENTRIES;i++){
		
			if(bsmap[i].pid==pid){
		

				if(bsmap[i].vpage<=vp && (bsmap[i].vpage+bsmap[i].npages)>=vp){
					return i;
				
				}
			}	

		}
	kprintf("vp : %d  pid %d  bsmap %d\n",vp,pid,i);
	return SYSERR;
}

int getoffset(int vp, int i){


	return vp-bsmap[i].vpage;

}



int decrementref(int frameno){

	int fid=frameno-FRAME0;

   	kprintf("***************Dec ref*******\n"); 
	if(iptable[fid].fstate==F_TAB){
	
	
		iptable[fid].refcount= iptable[fid].refcount -1;

		if(iptable[fid].refcount==0){
		
		clearframe(frameno);

		}

		return OK;
	}
	kprintf("Frame %d  is not of P_TAB type\n",fid);
	return SYSERR;
}


int  clearframe(int frameno){
	
	int mybs,offset,bswrite;
	int fid =frameno-FRAME0;
	pid32 pid;
	int vp,p,q;
	unsigned long a;
	pd_t *pd;
	pt_t *pt;
	struct procent *prptr;
	uint32 frameclear;

   	kprintf("*************"); 
	kprintf("Free frame called on %d\n",fid+FRAME0);

	if(iptable[fid].fstate==F_GLOBAL ) {
	
	kprintf("Cannot clear frame of P_GLOBAL\n");
	return SYSERR;
	}
	if(iptable[fid].fstate==F_FREE)
	{
	kprintf("Cannot clear F_FREE FRAME\n");
	return SYSERR;}
//	
//	printiptab();
	
if(iptable[fid].fstate!=F_TAB &&  iptable[fid].fstate!=F_DIR )
  {
	kprintf("FRAME : %d => VPAGE : %d\ni",fid+FRAME0,iptable[fid].vpage);
	vp=iptable[fid].vpage;
	a=vp*4096;
//	kprintf("a ======> %u",a);
	p=a>>22;
	
	q=vp & 0x000003FF;
	
	pid=iptable[fid].pid;
	prptr =&proctab[pid];

	pd=prptr->pdir;
	pt=(pt_t *)(pd[p].pd_base<<12);
	

	if(pt[q].pt_dirty==1){
		mybs=checkbsmap(iptable[fid].vpage,iptable[fid].pid);
        	if(SYSERR==mybs){
	        	kprintf("Not valid address for Free Frame\n");
	        	kill(iptable[fid].pid);
        	}
		

		offset=getoffset(iptable[fid].vpage,mybs);

		bswrite=write_bs(frameno<<12,mybs,offset);

		if(bswrite==SYSERR){
		
		kprintf("Could not write dirty page in bs\n");
		kill(iptable[fid].pid);
	
		}

	}



	if(iptable[fid].fstate==F_USED|| pt[q].pt_dirty==1){
	
//		kprintf("PDIRRRRRRRR============>  %u\n",(uint32)pd/4096);
//		kprintf("PT     ===========>  %u\n",(uint32)pt/4096);
	
//		kprintf("p=>%d    q=> %d\n",p,q);


		pt[q].pt_pres 	=0;
	//	pt[q].pt_write	=0;
		pt[q].pt_dirty	=0;
		pt[q].pt_base	=0;

	frameclear=((uint32)pt>>12);
	decrementref(frameclear);
	kprintf("Frame clear is %d\n",frameclear);

		if(iptable[frameclear-FRAME0].fstate==F_FREE){		// if tble is removed, then update directory data

			pd[p].pd_pres=0;
			pd[p].pd_base=0;

		}



	  }


  }



	if(iptable[fid].fstate==F_TAB){

		hook_ptable_delete(fid);
	}





	if(iptable[fid].pid==currpid){
	
	kprintf("Invalidating TLB\n");
	prptr= &proctab[currpid];
	setPDRegister(prptr->pdir);
	}






   int j;
   int prev; 
  
  
	//while(j!=iptail)

    if(frameno==iphead){
     
     iphead=iptable[fid].fnext;
   }

else{
     	for(j=0;j<NFRAMES;j++){
     
    	
    	 if (iptable[j].fnext==frameno)	{
	 iptable[j].fnext=iptable[fid].fnext; 

		if(frameno==iptail){
		iptail=j+FRAME0;

		}

		break;
	}



     }
  }
 
     iptable[fid].fstate=F_FREE;
     iptable[fid].vpage=0;
     iptable[fid].fnext=-1;
     iptable[fid].pid=-1;
     


//	printiptab();

     availframes++;
     kprintf("%d frames avaial in freeframe\n",availframes); 
}

void clearTab(pt_t *pt){

	clearframe((uint32)pt>>12);


}



void clearDir(pd_t *pd){

int i;

	for (i=4;i<PTENTRIES;i++){
	
	if(i!=576){
		if(pd[i].pd_pres==1 ){
		
		clearTab((pt_t *)(pd[i].pd_base<<12));
		}

	}


      }

    clearframe((uint32)pd>>12);

}


void killCleanup(pid32 pid){

	struct procent *prptr;
	int curr=iphead;
	int prev=-1;
	int i;

	//kprintf("IPHEAD %d \t IPTAIL %d\n",iphead,iptail);
       //	printiptab();	
 	kprintf("KILLCELAN UP for proces %d\n",pid);
	
if(spolicy==FIFO)	
{	while((curr)!=iptable[iptail-FRAME0].fnext){
//	kprintf("In loop\n");
	
	if(pid==iptable[curr-FRAME0].pid && iptable[curr-FRAME0].fstate!=F_DIR && iptable[curr-FRAME0].fstate!=F_TAB ){
		

		kprintf("kILL Clearing frame %d for %d\n",curr,pid);
		
		if(curr==iphead && curr==iptail){
		//	kprintf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");	
			clearframe(curr);
			iphead=iptail=-1;
			break;
			

		}else	if(curr==iphead){
			iphead=iptable[curr-FRAME0].fnext;		
			clearframe(curr);
			curr=iphead;
		}	
		else if(curr==iptail){
		//	kprintf("Curr is iptail %d\n",prev);			
			iptable[prev-FRAME0].fnext=-1;
			clearframe(curr);
			iptail=prev;
			curr=iptable[iptail-FRAME0].fnext;;

		}
		else
		{
		iptable[prev-FRAME0].fnext=iptable[curr-FRAME0].fnext;
		clearframe(curr);
		curr=iptable[prev-FRAME0].fnext;

		}
	}
	else{
		prev=curr;
		curr=iptable[curr-FRAME0].fnext;
		}
	}


	curr=iphead;
	prev=-1;

	while((curr)!=iptable[iptail-FRAME0].fnext){
//	kprintf("In loop\n");
	
	if(pid==iptable[curr-FRAME0].pid && iptable[curr-FRAME0].fstate!=F_DIR ){
		

		kprintf("kILL Clearing frame %d for %d\n",curr,pid);
		
		if(curr==iphead && curr==iptail){
		//	kprintf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");	
			clearframe(curr);
			iphead=iptail=-1;
			break;
			

		}else	if(curr==iphead){
			iphead=iptable[curr-FRAME0].fnext;		
			clearframe(curr);
			curr=iphead;
		}	
		else if(curr==iptail){
		//	kprintf("Curr is iptail %d\n",prev);			
			iptable[prev-FRAME0].fnext=-1;
			clearframe(curr);
			iptail=prev;
			curr=iptable[iptail-FRAME0].fnext;;

		}
		else
		{
		iptable[prev-FRAME0].fnext=iptable[curr-FRAME0].fnext;
		clearframe(curr);
		curr=iptable[prev-FRAME0].fnext;

		}
	
	}
	else{
		prev=curr;
		curr=iptable[curr-FRAME0].fnext;
		}
	}


	
}
else
{
	
	
		for(i=0;i<NFRAMES;i++){
		
		
		if(pid==iptable[i].pid && iptable[i].fstate!=F_DIR && iptable[i].fstate!=F_TAB){
		
			clearframe(i+FRAME0);
				
		}
	}



		for(i=0;i<NFRAMES;i++){
		
		
		if(pid==iptable[i].pid && iptable[i].fstate!=F_DIR){
		
			clearframe(i+FRAME0);
				
		}
	}



}

prptr=&proctab[pid];

clearDir(prptr->pdir);

clearbsmap(pid);

}



void printiptab(){
int i;

return;
	for(i=0;i<NFRAMES;i++){
	
	kprintf("id %d  pid %d state %d  vpage %d  next %d\n",i,iptable[i].pid,iptable[i].fstate,iptable[i].vpage,iptable[i].fnext);  

	} 

}


