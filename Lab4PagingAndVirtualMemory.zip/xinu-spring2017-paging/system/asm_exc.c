#include <xinu.h>



unsigned long temp;






void writecr0(unsigned long n) {

	intmask mask;
	mask = disable();

	temp = n;
	asm("pushl %eax");
	asm("movl temp, %eax");
	asm("movl %eax, %cr0");
	asm("popl %eax");
	restore(mask);
}


unsigned long readcr0(){

	int mask;
	unsigned long  ans;
	mask=disable();


	asm("pushl %eax");
	asm("movl %cr0, %eax");
	asm("movl %eax, temp");
	asm("popl %eax");

	ans=temp;
	restore(mask);
	return ans;
}



unsigned long readcr2(){

	int mask;
	unsigned long  ans;
	mask=disable();


	asm("pushl %eax");
	asm("movl %cr2, %eax");
	asm("movl %eax, temp");
	asm("popl %eax");

	ans=temp;
	restore(mask);
	return ans;
}


void writecr3(unsigned long n) {

	intmask mask;
	mask = disable();

	temp = n;
	asm("pushl %eax");
	asm("movl temp, %eax");
	asm("movl %eax, %cr3");
	asm("popl %eax");
	restore(mask);
}


unsigned long readcr3(){

	int mask;
	unsigned long  ans;
	mask=disable();


	asm("pushl %eax");
	asm("movl %cr3, %eax");
	asm("movl %eax, temp");
	asm("popl %eax");

	ans=temp;
	restore(mask);
	return ans;
}


void setPDRegister(unsigned long addr){
	
	
	writecr3(addr);

}



void enablePaging(){

	unsigned long int ans;
	temp=readcr0();
	ans=temp | (0x1 << 31 );
	writecr0(ans);
}

