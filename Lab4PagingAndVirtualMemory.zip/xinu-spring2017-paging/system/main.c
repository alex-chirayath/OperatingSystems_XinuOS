/*  main.c  - main */

#include <xinu.h>
#include <stdio.h>

#define PAGESIZE  (4096)
#define MAGIC_VALUE (1205)
#define MAX_STORES (8)
#define MAX_PAGES_PER_STORE (200)
#define WAITTIME (5000)
#define PAGE_ALLOCATION (100)
#define NCHILD_PROC (4)

#define GENTLE_TCS (4)
#define TC (4)

#define MSG_SUCC (10000)
#define MSG_FAIL (20000)
#define MSG_ERR (30000)


// to save CR0 value
unsigned long cr0val;
/**
 * @return true if paging is indeed turned on.
 * This check should be put before any real test.
 */
static bool8 paging_enabled() {
	// fetch CR0
	asm("pushl %eax");
	asm("movl %cr0, %eax");
	asm("movl %eax, cr0val");
	asm("popl %eax");

	// check if the 31th bit is set
	return cr0val & 0x80000000 ? TRUE : FALSE;
}

// ===== Test Cases =====
static void tc();


process	main(void)
{
	srpolicy(GCA);

	/* Start the network */
	/* DO NOT REMOVE OR COMMENT THIS CALL */
	netstart();

	/* Initialize the page server */
	/* DO NOT REMOVE OR COMMENT THIS CALL */
	psinit();

	kprintf("=== Test Case %d - NFRAMES %d, POLICY %s ===\n", TC, NFRAMES, "FIFO");

	if (!paging_enabled()) {
		kprintf(" PAGING IS NOT ENABLED!! Thus failed TC %d\n", TC);
		return OK;
	}

	tc();
	kprintf("=== Page replacement policy test %d completed ===\n", TC);
	return OK;
}


// ===== Actual Test Cases Below =====

local void policytest() {
	uint32 npages = PAGE_ALLOCATION - 1;
	uint32 nbytes = npages * PAGESIZE;

	kprintf("Running Page Replacement Policy Test, with NFRAMES = %d\n", NFRAMES);

	char *mem = vgetmem(nbytes);
	if (mem == (char*) SYSERR) {
		kprintf("Page Replacement Policy Test failed. Could not get vmem??\n");
		return;
	}

	char *p = mem;
	uint32 i;
	for (i = 0; i < npages - 1; i++) {
		kprintf("\rIteration [%3d]", i);
		*p = 10;
		sleepms(20); // to make it slower
		p += PAGESIZE; // go to next page
	}

	if (vfreemem(mem, nbytes) == SYSERR) {
		kprintf("Policy Test: vfreemem() failed?? Still count this as failure\n");
		return;
	}
	else {
		kprintf("\nGRADING : Page Replacement Policy Test Finished.\n");
		kprintf("Here NFRAMES = %d\n", NFRAMES);
		kprintf("If NFRAMES is not small (e.g. 50), it's not acceptable, also consider this to be wrong. 3072 is definitely not acceptable\n");
	}
}

/**
 * Just iterate through a lot of pages, and check if the output satisfies the policy.
 */

void test(void){
int *a, *b;

a=(int*)vgetmem(4);
kprintf(" pid %d The value of a is 0x%08x value %d\n ",currpid, a,*a);    //(0)
*a=currpid;
kprintf("pid %d The value of a is 0x%08x\n ", currpid, a);  // (1)

kprintf("pid=%d, a at location 0x%08x value %d\n",currpid,a,*a);

vfreemem((char*)a,4);

b=(int*)vgetmem(8);
kprintf("pid %d The value of b is 0x%08x\n ", currpid, b);

kprintf("pid=%d, b at location 0x%08x value %d\n",currpid,b,*b);


*b=currpid*2;

kprintf("pid=%d, at location 0x%08x value %d\n",currpid,b,*b);

return;
}

void tc() {
    recvclr();
    sid32 mutex = semcreate(1);
    pid32 p1=(vcreate(test, 8192, 200,100, "1", 0, NULL));
    pid32 p2=(vcreate(test, 8192, 200,100, "2", 0, NULL));
    resume(p1);
    resume(p2);

    sleepms(1000);
    pid32 p3=(vcreate(test, 8192, 200,50, "3", 0, NULL));

    resume(p3);

    return;
}



/*
static void tc() {
	recvclr();

	pid32 p = vcreate(policytest, INITSTK, PAGE_ALLOCATION, INITPRIO, "page rep", 0, NULL);
	resume(p);

	while (1) {
		if(proctab[p].prstate == PR_FREE) {
			break;
		}
		else {
			sleepms(100);
		}
	}

	kprintf("\n\nThe correctness of this test still needs you to look at the runtime outputs.. See if it's FIFO?\n\n");
	return;
}*/
