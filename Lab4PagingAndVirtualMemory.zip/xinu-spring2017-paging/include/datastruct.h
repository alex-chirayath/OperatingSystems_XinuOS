
#define PGFAULT 14

#ifndef MAX_BS_ENTRIES
#define MAX_BS_ENTRIES MAX_ID - MIN_ID + 1
#endif

// ---------------page size--------------------
#define PTENTRIES 1024
#define PGSIZE	  4096
#define DEVICEMEM 576*1024

void enablepaging();				//start Paging

extern void iptableinit(void);
extern void bsmapinit(void);
extern int globalTabinit(void);

extern uint32 faults;
extern int iphead,iptail;

extern void killCleanup(pid32);
extern void printdir(char* addr);
 
typedef struct	bstoremap	{
        pid32 pid;
		unsigned int vpage:20;
		int npages;
	}backstoremap;


extern	backstoremap bsmap[MAX_BS_ENTRIES];	
int checkbsmap(unsigned long, pid32 );
int getoffset(int , int );
int getGCAcandidate();


typedef struct ivptable {

	pid32 pid;
	unsigned int vpage :20;	
	
	int fstate;
//	unint32 fifots;
//	struct ivptable *next;
	int refcount;
	int fnext;


	}invptable;

extern	invptable iptable[NFRAMES];	

extern void printiptab();


//====================FRAME DEFINITION===========================


#define F_FREE		0
#define F_GLOBAL	1
#define F_TAB		2
#define F_DIR		3	
#define F_USED		4
#define F_DIRTY		5


//======================BS MAP===========================

int bscounter(void);

syscall heaptobsmap(pid32);
syscall clearbsmap(pid32);
void addbsmapp(bsd_t ,pid32 ,uint32 ,uint32);
void printbsmap(void);

// =================== POLICY============

extern uint32 spolicy;
extern int    availframes;
