/* chgprio.c - chgprio */
/*LAB 1*/
#include <xinu.h>

/*------------------------------------------------------------------------
 *  chprio  -  Change the scheduling priority of a process GROUP
 *------------------------------------------------------------------------
 */



pri16	chgprio(
	  int		group,		/* ID of process GROUP	*/
	  pri16		newprio		/* New priority			*/
	)
{
	intmask	mask;			/* Saved interrupt mask		*/

//struct procent *prptr;		/* Ptr to process's table entry	*/
	pri16	oldprio;		/* Priority to return		*/


	mask = disable();
/*	if (isbadpid(pid)) {
		restore(mask);
		return (pri16) SYSERR;
	}

	prptr = &proctab[pid];
	oldprio = prptr->prprio;
	prptr->prprio = newprio;
*/
	
	if(group ==TSSCHED)
	{
	oldprio=tsprio;
	TSINITGPRIO = newprio;
	}
	if(group ==PROPORTIONALSHARE)
	{
	oldprio=psprio;
	PSINITGPRIO =newprio;
	}


	restore(mask);
	return oldprio;
}
