/*  main.c  - main */

#include <xinu.h>



void myprocessone(void) {
                int i;
               for(i=1; i<1000000; i++)       // SEMICOLON AT THE END
                          kprintf("IIIIIIIIIIIII: %d!\n", i);
		}


process main(void)
        {
	             kprintf("Main\n");
		      recvclr();
		     resume(create(myprocessone, 4096, PROPORTIONALSHARE, 20, "hello", 0));
			
	}
   
