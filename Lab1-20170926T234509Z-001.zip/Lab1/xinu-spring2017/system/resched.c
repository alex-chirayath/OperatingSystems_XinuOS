/* resched.c - resched, resched_cntl */

#include <xinu.h>

struct	defer	Defer;

/*------------------------------------------------------------------------
 *  resched  -  Reschedule processor to highest priority eligible process
 *------------------------------------------------------------------------
 */
uint32 tickstime;

int aging_sched(
 struct procent *ptold
)
{
		int qhead;
		int qtail;
		int currnode;
		int next;
		int psno=0;
		int tsno=0;
		
		//kprintf("  **AGING SCHED**\n");

		if(ptold->grpid== TSSCHED)
		{
			//kprintf("Current Process in TS: \t %s\n",ptold->prname);
			tsprio=TSINITGPRIO	;
		}

		if(ptold->grpid==PROPORTIONALSHARE)
		{
			//kprintf("Current Process in PS: \t %s\n",ptold->prname);
			psprio=PSINITGPRIO;
		}


		 qhead=queuehead(readylist);
		 qtail=queuetail(readylist);
		 currnode=qhead;

		while(queuetab[currnode].qnext!=qtail)
		{	
			next=queuetab[currnode].qnext;
	
			if(next==NULLPROC)//Is this correct identifier?
			{}
			else if(proctab[next].grpid==TSSCHED)
			{
			tsno++;
			}
			else if(proctab[next].grpid==PROPORTIONALSHARE)
			{
			psno++;
			}

		currnode=next;
		}
		tsprio=tsprio+tsno;
		psprio=psprio+psno;
	
	//chgprio(TSSCHED,tsprio);
	//chgprio(PROPORTIONALSHARE,psprio);

	
		if(psno==0 && tsno==0)			// either ready list has null process or only null process left 
			{
				//kprintf("ITS -1!!!!!\n");
				return -1;
			}
	
		if(tsno==0)
			{
		//kprintf("TS==0\n");
			return PROPORTIONALSHARE;
			}
		if(psno==0)
			{
		//kprintf("PS==0\n");
			return TSSCHED;
			}
	
	
		if(psprio>=tsprio)
			{
			return PROPORTIONALSHARE;
			}
		if(tsprio>psprio)
			return TSSCHED;

return -2;

}





pid32 findCandidatePS()
	{

		pid32 replacement_id=-1;
		int qhead=queuehead(readylist);
		int qtail=queuetail(readylist);
		int currnode=qhead;		
		int next;
		int min_pi;

		
		while(queuetab[currnode].qnext!=qtail)
		{		
			next=queuetab[currnode].qnext;
				if( proctab[next].grpid==PROPORTIONALSHARE )
					{
					min_pi=proctab[next].pi;
					replacement_id=next;
					break;
					}
			currnode=next;

		}
				

		while(queuetab[currnode].qnext!=qtail)
		{
			next=queuetab[currnode].qnext;
			      
				if(proctab[next].pi<min_pi && proctab[next].grpid==PROPORTIONALSHARE )
					{
					min_pi=proctab[next].pi;
					replacement_id=next;
					
					}

			currnode=next;
		}

		return replacement_id;
	
	}

		

pid32 findCandidateTS()
	{

		pid32 replacement_id=-1;
		int qhead=queuehead(readylist);
		int qtail=queuetail(readylist);
		int currnode=qhead;		
		int next;
		pri16 max_prio=-1;

		while(queuetab[currnode].qnext!=qtail)
		{
			next=queuetab[currnode].qnext;
			      
				if(proctab[next].prprio>max_prio && proctab[next].grpid==TSSCHED )
					{
					max_prio=proctab[next].prprio;
					replacement_id=next;
					
					}

			currnode=next;
		}
		return replacement_id;
	
	}		

	



void	resched(void)		/* Assumes interrupts are disabled	*/
{
	struct procent *ptold;	/* Ptr to table entry for old process	*/
	struct procent *ptnew;	/* Ptr to table entry for new process	*/




	
	int group;
	pid32 replacement_id;
	//int tssched_new_prio=-1;
	//int tssched_quantum=-1;
	


	//kprintf("**************RESCHED \t Current no of proc:   %d *******************\n",prcount);
	
	
	if (Defer.ndefers > 0) {
		Defer.attempt = TRUE;
		return;
	}

	
	ptold = &proctab[currpid];


	
		if(ptold->grpid==PROPORTIONALSHARE)				//update current process only when it if from PS
		{
			
			//kprintf("Current process is in PS \t");
			
			//kprintf("Updating time consumed for current from %d to %d \n",&ptold->time_consumed,(QUANTUM-preempt));
			ptold->time_consumed=QUANTUM-preempt;
			
			if(ptold->time_consumed==0)
				ptold->time_consumed=QUANTUM;
			
			//kprintf("Current Process : %s  Initial Pi to : %d\n",ptold->prname,ptold->pi);

			ptold->pi = ptold->pi + ((ptold->time_consumed*100)/ptold->rate);
			
			//ptold->prprio=MAXINT- ptold->pi;
			//kprintf("Current Process : %s  updated Pi to : %d\n",ptold->prname,ptold->pi);

		}

		if(ptold->grpid==TSSCHED)	//update current process only when it if from PS
		{


//			kprintf("Current process is in TS \n");
			//kprintf("Updating time consumed for current from %d to %d \n",&ptold->time_consumed,(QUANTUM-preempt));
			

			
			//if(ptold->prprio>59)								//if prio exceeds 59
				//	ptold->prprio=59;

			if((QUANTUM-preempt)>0)								// if blocking
				{

					
					ptold->prprio=unix_table[ptold->prprio][1];
					ptold->time_consumed=unix_table[ptold->prprio][2];
				}
			else													// non-blocking
				{
					ptold->prprio=unix_table[ptold->prprio][0];
					ptold->time_consumed=unix_table[ptold->prprio][2];;
				}
		
		}
		
		group=aging_sched(ptold);//Check the groups


		
		

		if(group==-1)  // either null left running or only null in readylist
			{
			//	kprintf("Group returned as -1\n");
				if(currpid==NULLPROC)	
					{
				//	kprintf("Null Proc only left and so we keep it running\n");
					return;
					}		
				else
					{
						
						
						


						//kprintf("Switch to null as only that is in readylist\n");		// we are switching to null even if current may be left
						
						
						if(ptold->prstate==PR_CURR)
						{

							if(ptold->grpid==PROPORTIONALSHARE && ptold->pi<= proctab[NULLPROC].pi)
								{
						//		kprintf("Only null process left in ready list and current TS Process contiues\n:");
								return;
								}

						ptold->prstate=PR_READY;						
						insert(currpid,readylist,ptold->prprio);
						
						}
					//	kprintf("Switching to null process as only that is in ready list\n");


						currpid=getitem(NULLPROC);

						
						ptnew=&proctab[currpid];
						ptnew->prstate=PR_CURR;
			

					/*if(ptnew->pi==0||(ptnew->time_consumed>0 &&  ptnew->time_consumed< QUANTUM)) //is this condition enough to check for blocking?
						{
							kprintf("Blocking or new process selected from PS\n");
								if (ptnew->pi<tickstime)
								{
									kprintf("Pi is less than ticks time: %d\n",tickstime);
									ptnew->pi=tickstime;
								}
							else {
									kprintf("Pi is not less than ticks time: %d\n",tickstime);
								}					
						}

						kprintf("Switching to NEW(NULL) PS Process=> %s with pi= %d\n ",ptnew->prname,ptnew->pi );
						

						preempt=QUANTUM;
						ctxsw(&ptold->prstkptr, &ptnew->prstkptr);
						return;
					*/				
						preempt=ptnew->time_consumed;
						ctxsw(&ptold->prstkptr, &ptnew->prstkptr);
						return;
					}	
			}
		
			
		if(group==PROPORTIONALSHARE)
			{	
				   replacement_id=findCandidatePS();			
	         	//	kprintf("Replacement found by candidate PS:  %s  with pi %d\n",proctab[replacement_id].prname,proctab[replacement_id].pi);
				
						//ptold->prevprstate=PR_CURR;		//store previous pr state
		




					if(ptold->prstate==PR_CURR )
						{
				
							if(replacement_id==-1 || (ptold->grpid==PROPORTIONALSHARE &&ptold->pi < proctab[replacement_id].pi))
								{
							//	kprintf("Current PS Process Continues \n");
								return;
								}
							
							ptold->prstate=PR_READY;	
							insert(currpid,readylist,ptold->prprio);
						

						}




					
				currpid=getitem(replacement_id);

				ptnew=&proctab[currpid];
				ptnew->prstate=PR_CURR;
			

				if(ptnew->pi==0||(ptnew->time_consumed>0 &&  ptnew->time_consumed< QUANTUM)) //is this condition enough to check for blocking?
					{
						//kprintf("Blocking or new process selected from PS\n");
							if (ptnew->pi<tickstime)
								{
								//	kprintf("Pi is less than ticks time: %d\n",tickstime);
									ptnew->pi=tickstime;
								}
							else {
								//	kprintf("Pi is not less than ticks time: %d\n",tickstime);
								}					
							}

				//kprintf("Switching to NEW PS Process=> %s with pi= %d\n ",ptnew->prname,ptnew->pi );
				preempt=QUANTUM;
				ctxsw(&ptold->prstkptr, &ptnew->prstkptr);
				return;





		 }





		if(group==TSSCHED)
			{


			replacement_id=findCandidateTS();
			//kprintf("Current process is %s from group %d with Prio= %d and Pi = %d \n",ptold->prname,ptold->grpid,ptold->prprio,ptold->pi);	
			if(ptold->prstate == PR_CURR )
						{
				
							if(replacement_id==-1 || (ptold->grpid==TSSCHED && ptold->prprio> proctab[replacement_id].prprio))
								{
								preempt=ptold->time_consumed;
								//kprintf("Current TS Process Continues \n");
								return;
								}
							
							ptold->prstate=PR_READY;	
							insert(currpid,readylist,ptold->prprio);
						

						}

		  	       currpid=getitem(replacement_id);

				ptnew=&proctab[currpid];
				ptnew->prstate=PR_CURR;

						


				

			//	kprintf("Switching to NEW TS Process=> %s with pRIO= %d\n ",ptnew->prname,ptnew->prprio );
				preempt=ptnew->time_consumed; //here it is new quantum
				ctxsw(&ptold->prstkptr, &ptnew->prstkptr);
				return;





			}


	
	/* ********************************************************* */






}

/*------------------------------------------------------------------------
 *  resched_cntl  -  Control whether rescheduling is deferred or allowed
 *------------------------------------------------------------------------
 */
status	resched_cntl(		/* Assumes interrupts are disabled	*/
	  int32	defer		/* Either DEFER_START or DEFER_STOP	*/
	)
{
	switch (defer) {

	    case DEFER_START:	/* Handle a deferral request */

		if (Defer.ndefers++ == 0) {
			Defer.attempt = FALSE;
		}
		return OK;

	    case DEFER_STOP:	/* Handle end of deferral */
		if (Defer.ndefers <= 0) {
			return SYSERR;
		}
		if ( (--Defer.ndefers == 0) && Defer.attempt ) {
			resched();
		}
		return OK;

	    default:
		return SYSERR;
	}
}
